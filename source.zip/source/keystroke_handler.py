import math
from typing import List, Dict
#
class KeystrokeHandler:
    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self.press_times: List[float] = []
        self.release_times: List[float] = []
        self.keys_pressed: List[str] = []

        self.dwell_times: List[float] = []
        self.flight_times: List[float] = []
        self.latency: List[float] = []
        self.intervals: List[float] = []

    def process_events(self, events: List[Dict]) -> None:
        self.reset()
        events = sorted(events, key=lambda e: e.get("t", 0))
        press_map: Dict[str, List[float]] = {}

        for e in events:
            key = str(e.get("key", ""))
            event_type = e.get("type")
            t = float(e.get("t", 0.0)) / 1000.0

            if event_type == "down":
                self.press_times.append(t)
                self.keys_pressed.append(key)
                if len(self.press_times) > 1:
                    self.latency.append(t - self.press_times[-2])
                if len(self.release_times) > 0:
                    self.flight_times.append(t - self.release_times[-1])
                press_map.setdefault(key, []).append(t)

            elif event_type == "up":
                self.release_times.append(t)
                if len(self.release_times) > 1:
                    self.intervals.append(t - self.release_times[-2])
                if key in press_map and press_map[key]:
                    down_t = press_map[key].pop(0)
                    self.dwell_times.append(max(0.0, t - down_t))

    def dataSummary(self) -> Dict:
        def avg(values: List[float]) -> float:
            return (sum(values) / len(values)) if values else 0.0

        def stdev(values: List[float]) -> float:
            if len(values) < 2:
                return 0.0

            mean = sum(values) / len(values)
            variance = sum((x - mean) ** 2 for x in values) / (len(values) - 1)
            variance = max(variance, 0.0)
            return math.sqrt(variance)

        return {
            "keys": len(self.keys_pressed),

            "avg_dwell_ms": round(avg(self.dwell_times) * 1000.0, 2),
            "std_dwell_ms": round(stdev(self.dwell_times) * 1000.0, 2),

            "avg_flight_ms": round(avg(self.flight_times) * 1000.0, 2),
            "std_flight_ms": round(stdev(self.flight_times) * 1000.0, 2),

            "avg_latency_ms": round(avg(self.latency) * 1000.0, 2),
            "std_latency_ms": round(stdev(self.latency) * 1000.0, 2),

            "avg_interval_ms": round(avg(self.intervals) * 1000.0, 2),
            "std_interval_ms": round(stdev(self.intervals) * 1000.0, 2),

            "samples": {
                "dwell": len(self.dwell_times),
                "flight": len(self.flight_times),
                "latency": len(self.latency),
                "interval": len(self.intervals),
            }
        }