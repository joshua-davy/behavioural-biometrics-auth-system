import json
import math

def parse_samples(raw):
    try:
        return json.loads(raw)
    except:
        return []

def valid_samples(samples, expected_attempts=3, expected_length=8):
    if not isinstance(samples, list):
        return False
    if len(samples) != expected_attempts:
        return False

    for sample in samples:
        if not isinstance(sample, list):
            return False
        if len(sample) != expected_length:
            return False
    return True

def valid_sample(sample, expected_length=8):
    if not isinstance(sample, list):
        return False
    if len(sample) != expected_length:
        return False

    return True

def averagesList(samples):
    length = len(samples[0])
    avg = []

    for i in range(length):
        vals = [s[i] for s in samples]
        avg.append(round(sum(vals) / len(vals), 2))
    return avg

def stdList(samples):
    length = len(samples[0])
    std = []

    for i in range(length):
        vals = [s[i] for s in samples]
        if len(vals) < 2:
            std.append(0.0)
        else:
            mean = sum(vals) / len(vals)
            variance = sum((x - mean) ** 2 for x in vals) / (len(vals) - 1)
            variance = max(variance, 0.0)
            std.append(round(math.sqrt(variance), 2))

    return std

def build_profile(samples):
    return {
        "avg_profile": averagesList(samples),
        "std_profile": stdList(samples)
    }

def mouse_statsRange(stored_profile, login_profile, epsilon=1e-6):
    stored_avg = stored_profile["avg_profile"]
    stored_std = stored_profile["std_profile"]
    login_avg = login_profile["avg_profile"]
    z_scores = {}
    z_values = []

    for i in range(len(stored_avg)):
        mu = stored_avg[i]
        x = login_avg[i]
        sigma = max(stored_std[i], 20.0)
        z = abs(x - mu) / (sigma + epsilon)
        z_scores[f"transition_{i + 1}"] = round(z, 3)
        z_values.append(z)

    sorted_z_values = sorted(z_values)
    if len(sorted_z_values) > 2:
        trimmed_z_values = sorted_z_values[:-2]
    else:
        trimmed_z_values = sorted_z_values
    trim_avg_z = round(sum(trimmed_z_values) / len(trimmed_z_values), 3)
    trim_max_z = round(max(trimmed_z_values), 3)
    similarity = round(1 / (1 + trim_avg_z), 3)

    return trim_avg_z, trim_max_z, similarity, z_scores

